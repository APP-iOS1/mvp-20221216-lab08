//
//  Search.swift
//  Touche
//
//  Created by 조석진 on 2022/12/19.
//

import Foundation

struct Search {
    var brandNames: [String] = []
}
